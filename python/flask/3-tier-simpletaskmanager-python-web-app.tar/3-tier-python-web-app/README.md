project_root/
├── frontend/
│   ├── app.py
│   └── templates/
│       └── index.html
├── backend/
│   └── app.py
└── requirements.txt
