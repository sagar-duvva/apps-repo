import os
from flask import Flask, render_template, request, redirect, url_for
import requests

app = Flask(__name__)

# It will grab 'http://backend:5001/api/tasks' from the docker-compose file
BACKEND_URL = os.environ.get("BACKEND_URL", "http://backend:5001/api/tasks")


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        title = request.form.get('title')
        if title:
            try:
                # Send data to the backend API
                requests.post(BACKEND_URL, json={'title': title})
            except requests.exceptions.RequestException as e:
                print(f"Failed to reach backend: {e}")
        return redirect(url_for('index'))

    # GET request: Fetch data from the backend API gracefully
    try:
        response = requests.get(BACKEND_URL)
        response.raise_for_status() # Catches 400/500 backend errors
        tasks = response.json()
    except Exception as e:
        # Unmask the error by printing the exact exception string
        tasks = [{'title': f'Error details: {str(e)}'}]

    return render_template('index.html', tasks=tasks)
