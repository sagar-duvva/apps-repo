from flask import Flask

# Initialize the Flask application
app = Flask(__name__)

# Define the main route (the homepage)
@app.route('/')
def home():
    return """
    <h1>Hello, World!</h1>
    <p>Welcome to your new Python web application.</p>
    """

# Define a second route to show how routing works
@app.route('/about')
def about():
    return "<h2>About Page</h2><p>This is a simple Flask app.</p>"

# Run the app
if __name__ == '__main__':
    # debug=True automatically restarts the server when you make code changes
    app.run(debug=True, host='0.0.0.0', port=5000)
